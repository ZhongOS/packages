# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


# This file intentionally uses hard-coded brand names instead of Fluent terms.
# This approach minimizes issues across multiple release channels and rebranded
# versions.

default-bookmarks-title = 书签
default-bookmarks-heading = 书签

default-bookmarks-toolbarfolder = 书签工具栏文件夹
default-bookmarks-toolbarfolder-description = 此文件夹的书签会出现在书签工具栏上

# link title for https://www.mozilla.org/firefox/central/
default-bookmarks-getting-started = 新手上路

# Firefox links folder name
default-bookmarks-firefox-heading = Mozilla Firefox

# link title for https://www.mozilla.org/firefox/help/
default-bookmarks-firefox-get-help = 获取帮助

# link title for https://www.mozilla.org/firefox/customize/
default-bookmarks-firefox-customize = 定制 Firefox

# link title for https://www.mozilla.org/contribute/
default-bookmarks-firefox-community = 参与进来

# link title for https://www.mozilla.org/about/
default-bookmarks-firefox-about = 关于我们

# Firefox Nightly links folder name
default-bookmarks-nightly-heading = Firefox Nightly 资源

# Nightly builds only, link title for https://blog.nightly.mozilla.org/
default-bookmarks-nightly-blog = Firefox Nightly 博客

# Nightly builds only, link title for https://bugzilla.mozilla.org/
default-bookmarks-bugzilla = Mozilla 缺陷跟踪网站

# Nightly builds only, link title for https://developer.mozilla.org/
default-bookmarks-mdn = Mozilla 开发者网络

# Nightly builds only, link title for https://addons.mozilla.org/firefox/addon/nightly-tester-tools/
default-bookmarks-nightly-tester-tools = Nightly 测试者工具

# Nightly builds only, link title for about:crashes
default-bookmarks-crashes = 所有崩溃信息

# Nightly builds only, link title for https://planet.mozilla.org/
default-bookmarks-planet = Planet Mozilla
